import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='cristina',
    application_name='todo-list-serverless',
    app_uid='6jnrMXwgtlfzcmnxHL',
    org_uid='e69811e8-4ae9-4c9d-aa35-0e54d41769f2',
    deployment_uid='00180fed-7a25-443c-a56a-5d1da973e2eb',
    service_name='serverless-rest-api-with-dynamodb',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.4.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'serverless-rest-api-with-dynamodb-dev-create', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/create.create')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
